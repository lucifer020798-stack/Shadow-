# QA Checklist

## Static review
- [x] 10-character roster data exists.
- [x] 80 directional Special branches exist (8 directions x 10 characters), plus neutral/default Special.
- [x] Attack timing, hit detection, cooldown and energy systems are centralized in `scripts/game.gd`.
- [x] Campaign, training, roster and settings screens are wired.
- [x] Save/load configuration is implemented.
- [x] Online UI/code removed from this release as requested.
- [x] Android landscape configuration is present.

## Runtime tests to perform on a real Godot/Android environment
- [ ] Boot main scene.
- [ ] Select each champion.
- [ ] Run campaign stages 1–5.
- [ ] Verify all 8 joystick directions and diagonals.
- [ ] Verify 80 directional Specials and neutral Special.
- [ ] Verify attack startup/active/recovery and hit reactions.
- [ ] Verify energy/cooldowns/invalid-target behavior.
- [ ] Verify clone cap and lifetime.
- [ ] Verify teleport/phase boundaries.
- [ ] Verify boss-stage AI scaling.
- [ ] Verify save persistence after restart.
- [ ] Verify Android touch layout across aspect ratios.
- [ ] Verify 60 FPS target on supported devices.
- [ ] Verify release APK/AAB installation and signing.

No unchecked runtime item is represented as passed.

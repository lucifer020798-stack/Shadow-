# Changelog — 1.0.0-singleplayer

- Rebuilt the presentation around the supplied Shadow Legends concept direction.
- Added original SVG character-card artwork for all ten champions.
- Added original SVG arena artwork for five campaign locations.
- Reworked combat into a timed attack/special state flow with hit-stop, knockback, screen shake and VFX.
- Added 8-direction input parsing with diagonal recognition.
- Added 80 directional Special variants across ten champions.
- Added energy/cooldown/invulnerability/safety limits.
- Added five-stage campaign progression and local save data.
- Added rematch/result flow and settings.
- Removed online multiplayer from this release as requested.

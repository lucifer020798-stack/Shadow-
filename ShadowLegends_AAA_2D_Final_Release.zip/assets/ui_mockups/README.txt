Shadow Legends UI concept reference

ui_concept.png and shadow_legends_ui_reference.png are the supplied promotional UI concept artwork.
They are included as visual design references. The playable Godot UI is built by scripts/game.gd and does not yet reproduce every panel, graphic, or animation from the concept image pixel-for-pixel.
Do not treat the concept poster as a screenshot from a running build.

extends Node2D

# Shadow Legends: Beyond Reality — polished single-player 2D arena fighter
# Online multiplayer intentionally excluded from this build.

const W := 1280.0
const H := 720.0
const FLOOR_Y := 548.0
const ARENA_LEFT := 42.0
const ARENA_RIGHT := 1238.0
const MAX_HP := 100.0
const MAX_ENERGY := 100.0
const ROSTER := [
 {"name":"LUCIFER","title":"Infernal King","power":"HELLFIRE DASH","ultimate":"INFERNAL REALITY","color":Color("ff3d45"),"accent":Color("ff9d4d"),"style":"rushdown"},
 {"name":"GOLDEN NINJA","title":"Clone Sovereign","power":"INFINITE ECHO","ultimate":"CLONE INTERCEPT","color":Color("f3c84b"),"accent":Color("fff0a1"),"style":"clone"},
 {"name":"CHRONOS","title":"Time Sovereign","power":"TIME STOP","ultimate":"TIMELINE REWIND","color":Color("45c9ff"),"accent":Color("b6f2ff"),"style":"time"},
 {"name":"ASTRA","title":"Void Architect","power":"SPATIAL RIFT","ultimate":"DIMENSIONAL COLLAPSE","color":Color("b878ff"),"accent":Color("f1c8ff"),"style":"rift"},
 {"name":"MIMIC","title":"Ability Thief","power":"SKILL COPY","ultimate":"PERFECT COUNTER","color":Color("53e7a4"),"accent":Color("c4ffe2"),"style":"mimic"},
 {"name":"GRAVITY REIGN","title":"Singularity Lord","power":"GRAVITY WELL","ultimate":"BLACK SUN","color":Color("9f72ff"),"accent":Color("d9c3ff"),"style":"gravity"},
 {"name":"FROST ORACLE","title":"Winter Soul","power":"ABSOLUTE FREEZE","ultimate":"FROZEN TIMELINE","color":Color("8feaff"),"accent":Color("e2fbff"),"style":"frost"},
 {"name":"SOLAR TITAN","title":"Dawn Bringer","power":"STARBURST","ultimate":"ECLIPSE IMPACT","color":Color("ff9d3d"),"accent":Color("ffe39b"),"style":"solar"},
 {"name":"PHANTOM ZERO","title":"Phase Assassin","power":"PHASE SHIFT","ultimate":"UNTOUCHABLE","color":Color("b7c6ea"),"accent":Color("ffffff"),"style":"phase"},
 {"name":"CHAOS ORIGIN","title":"Reality Glitch","power":"REALITY GLITCH","ultimate":"CHAOS REWRITE","color":Color("ff5fc8"),"accent":Color("ffc3ec"),"style":"chaos"}
]

var selected := 0
var screen := "menu"
var mode := "campaign"
var stage := 0
var unlocked := 1
var wins := 0
var losses := 0
var match_time := 60.0
var round_over := false
var result_text := ""
var player_x := 330.0
var enemy_x := 950.0
var player_y := FLOOR_Y
var enemy_y := FLOOR_Y
var p_vy := 0.0
var e_vy := 0.0
var player_hp := MAX_HP
var enemy_hp := MAX_HP
var energy := MAX_ENERGY
var enemy_energy := 75.0
var guard := false
var invuln := 0.0
var freeze := 0.0
var slow := 0.0
var screen_shake := 0.0
var hitstop := 0.0
var flash := 0.0
var attack_timer := 0.0
var attack_kind := ""
var attack_hit := false
var combo := 0
var combo_timer := 0.0
var enemy_attack_timer := 0.0
var enemy_attack_kind := ""
var enemy_attack_hit := false
var ability_cd := 0.0
var ultimate_cd := 0.0
var ability_flash := 0.0
var clones: Array = []
var particles: Array = []
var texts: Array = []
var trails: Array = []
var last_dir := Vector2.RIGHT
var joystick_center := Vector2(115, 620)
var joystick_pos := joystick_center
var joystick_active := false
var left_move := false
var right_move := false
var block_hold := false
var settings_vibration := true
var show_fps := false
var sfx: Dictionary = {}
var audio_player: AudioStreamPlayer
var menu_time := 0.0
var message := "Choose a legend. The arena remembers every scar."
var message_timer := 4.0
var save_path := "user://shadow_legends_save.cfg"
var ui: CanvasLayer
var title_label: Label
var subtitle_label: Label
var hp_label: Label
var energy_label: Label
var enemy_label: Label
var timer_label: Label
var combo_label: Label
var message_label: Label
var roster_info: Label
var stage_info: Label
var settings_panel: PanelContainer
var roster_panel: PanelContainer
var campaign_panel: PanelContainer
var menu_buttons: Array = []

func _ready() -> void:
 randomize()
 _load_audio()
 _load_save()
 _build_ui()
 _show_screen("menu")
 queue_redraw()


func _load_audio()->void:
 audio_player=AudioStreamPlayer.new(); add_child(audio_player)
 for n in ["ui_click","hit_light","hit_heavy","special","ultimate","victory"]:
  sfx[n]=load("res://assets/audio/"+n+".wav")
func _sfx(n:String)->void:
 if audio_player!=null and sfx.has(n):
  audio_player.stream=sfx[n]
  audio_player.play()

func _build_ui() -> void:
 ui = CanvasLayer.new(); add_child(ui)
 # Top chrome
 var top := PanelContainer.new(); top.position=Vector2(18,14); top.size=Vector2(1244,70)
 top.add_theme_stylebox_override("panel", _box(Color("070b18e8"),Color("38557f"),2,14)); ui.add_child(top)
 var row:=HBoxContainer.new(); row.add_theme_constant_override("separation",18); top.add_child(row)
 title_label=_label("SHADOW LEGENDS",28,Color("ffd27a")); row.add_child(title_label)
 subtitle_label=_label("BEYOND REALITY  •  FIGHT  /  EVOLVE  /  CONQUER",12,Color("8ea7d0")); subtitle_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL; subtitle_label.vertical_alignment=VERTICAL_ALIGNMENT_CENTER; row.add_child(subtitle_label)
 var currency:=_label("◈  125,480     ◆  3,240",14,Color("dbe8ff")); row.add_child(currency)

 # Main menu
 var menu:=_panel(Vector2(36,110),Vector2(390,535),Color("0a1122ee"),Color("a86d38")); ui.add_child(menu); menu.name="Menu"
 var mv:=_vbox(menu,12); mv.add_child(_title("ENTER THE SHADOWS",25,Color("fff0cc"))); mv.add_child(_label("TEN WARRIORS  •  INFINITE POSSIBILITIES",12,Color("839bc0")))
 mv.add_child(_spacer(10))
 _menu_button(mv,"CAMPAIGN",func(): _show_screen("campaign"))
 _menu_button(mv,"VERSUS / TRAINING",func(): _start_battle("training"))
 _menu_button(mv,"CHAMPION ROSTER",func(): _show_screen("roster"))
 _menu_button(mv,"ARENA SELECT",func(): _show_screen("campaign"))
 _menu_button(mv,"HOW TO PLAY",func(): _set_message("Move with joystick • Attack/Kick • Direction + Special • Ultimate • Block • Jump"))
 _menu_button(mv,"SETTINGS",func(): _show_screen("settings"))
 mv.add_child(_spacer(5)); mv.add_child(_label("ORIGINAL 2D DARK-FANTASY ARENA FIGHTER",11,Color("657b9e")))

 # Roster
 roster_panel=_panel(Vector2(445,110),Vector2(800,535),Color("081226f2"),Color("315c8e")); ui.add_child(roster_panel)
 var rv:=_vbox(roster_panel,9); rv.add_child(_title("CHOOSE YOUR LEGEND",23,Color("e5efff"))); rv.add_child(_label("Every champion has a different rhythm, reach and reality-bending kit.",12,Color("8ea8d4")))
 var grid:=GridContainer.new(); grid.columns=2; grid.size_flags_vertical=Control.SIZE_EXPAND_FILL; grid.add_theme_constant_override("h_separation",9); grid.add_theme_constant_override("v_separation",7); rv.add_child(grid)
 for i in ROSTER.size():
  var idx:=i; var b:=Button.new(); b.custom_minimum_size=Vector2(350,54); b.text="%02d   %s\n      %s"%[idx+1,ROSTER[idx].name,ROSTER[idx].power]; b.alignment=HORIZONTAL_ALIGNMENT_LEFT; b.add_theme_font_size_override("font_size",12); b.add_theme_color_override("font_color",ROSTER[idx].accent); b.add_theme_stylebox_override("normal",_box(Color("0c1830"),ROSTER[idx].color,1,8)); b.pressed.connect(func(): selected=idx; _save(); _refresh_roster()); grid.add_child(b)
 roster_info=_label("",13,Color("c9d8ef")); rv.add_child(roster_info)
 var back:=Button.new(); back.text="← MAIN MENU"; back.pressed.connect(func(): _show_screen("menu")); rv.add_child(back)

 # Campaign
 campaign_panel=_panel(Vector2(445,110),Vector2(800,535),Color("081226f2"),Color("8b4f92")); ui.add_child(campaign_panel)
 var cv:=_vbox(campaign_panel,12); cv.add_child(_title("CAMPAIGN • THE ETERNAL WAR",24,Color("f2dcff"))); cv.add_child(_label("A five-stage reality fracture. Defeat each rival to unlock the next arena.",13,Color("a9a8cf")))
 stage_info=_label("",15,Color("ffd38c")); cv.add_child(stage_info)
 for s in 5:
  var ss:=s
  _menu_button(cv,"STAGE %d  •  %s"%[ss+1,["NEON CATHEDRAL","FRACTURED MOON","VOID TEMPLE","FROZEN CITADEL","REALITY CORE"][ss]],func(): stage=ss; _start_battle("campaign"))
 cv.add_child(_spacer(8)); cv.add_child(_label("Progress is saved locally. Boss stages gain new phases and faster AI.",12,Color("7389aa")))
 _menu_button(cv,"← MAIN MENU",func(): _show_screen("menu"))

 # Settings
 settings_panel=_panel(Vector2(350,140),Vector2(580,460),Color("081226f5"),Color("4d78aa")); ui.add_child(settings_panel)
 var sv:=_vbox(settings_panel,15); sv.add_child(_title("SETTINGS",25,Color("e6efff")))
 _menu_button(sv,"TOGGLE HAPTICS",func(): settings_vibration=!settings_vibration; _set_message("Haptics: %s"%["ON" if settings_vibration else "OFF"]))
 _menu_button(sv,"TOGGLE FPS",func(): show_fps=!show_fps)
 _menu_button(sv,"RESET PROGRESS",func(): unlocked=1; wins=0; losses=0; stage=0; _save(); _set_message("Progress reset."))
 _menu_button(sv,"← MAIN MENU",func(): _show_screen("menu"))

 # Battle HUD
 var battle:=Control.new(); battle.name="BattleHUD"; battle.size=Vector2(W,H); ui.add_child(battle)
 var hud:=_panel(Vector2(18,94),Vector2(1244,82),Color("060b17e8"),Color("344f78")); battle.add_child(hud)
 var hr:=HBoxContainer.new(); hr.add_theme_constant_override("separation",15); hud.add_child(hr)
 hp_label=_label("LUCIFER  100",16,Color("65f2b4")); hp_label.custom_minimum_size.x=240; hr.add_child(hp_label)
 energy_label=_label("ENERGY 100",14,Color("6fd9ff")); hr.add_child(energy_label)
 var fill:=Control.new(); fill.size_flags_horizontal=Control.SIZE_EXPAND_FILL; hr.add_child(fill)
 timer_label=_label("60",24,Color("ffe5a1")); hr.add_child(timer_label)
 enemy_label=_label("RIVAL  100",16,Color("ff7777")); enemy_label.custom_minimum_size.x=240; enemy_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT; hr.add_child(enemy_label)
 var exit:=Button.new(); exit.text="EXIT"; exit.custom_minimum_size=Vector2(78,42); exit.pressed.connect(func(): _show_screen("menu")); hr.add_child(exit)
 combo_label=_label("",18,Color("ffffff")); combo_label.position=Vector2(525,190); combo_label.size=Vector2(230,38); combo_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; battle.add_child(combo_label)
 message_label=_label("",14,Color("ffe2b4")); message_label.position=Vector2(240,670); message_label.size=Vector2(800,32); message_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; battle.add_child(message_label)
 # Touch controls: custom joystick + action cluster
 var jbg:=_circle_button("",joystick_center,92,Color("09182de0"),Color("3a8fc9")); battle.add_child(jbg); jbg.gui_input.connect(_joystick_input)
 var knob:=_circle_button("",joystick_center,44,Color("15365be8"),Color("67d9ff")); knob.name="JoystickKnob"; battle.add_child(knob)
 for spec in [["JUMP",Vector2(200,610),72,"jump"],["ATK",Vector2(765,610),72,"attack"],["KICK",Vector2(845,650),72,"kick"],["BLOCK",Vector2(845,570),72,"block"],["SPECIAL",Vector2(925,610),92,"special"],["ULT",Vector2(1030,590),112,"ultimate"]]:
  _action_button(battle,spec[0],spec[1],spec[2],spec[3])

 # Keep refs in group via metadata
 battle.set_meta("visible_in_battle",true)

func _panel(pos:Vector2,size:Vector2,fill:Color,border:Color)->PanelContainer:
 var p:=PanelContainer.new(); p.position=pos; p.size=size; p.add_theme_stylebox_override("panel",_box(fill,border,2,12)); return p
func _box(fill:Color,border:Color,width:int,radius:int)->StyleBoxFlat:
 var s:=StyleBoxFlat.new(); s.bg_color=fill; s.border_color=border; s.set_border_width_all(width); s.set_corner_radius_all(radius); s.content_margin_left=14; s.content_margin_right=14; s.content_margin_top=10; s.content_margin_bottom=10; return s
func _vbox(parent:Control,gap:int)->VBoxContainer:
 var v:=VBoxContainer.new(); v.add_theme_constant_override("separation",gap); parent.add_child(v); v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); return v
func _label(t:String,size:int,color:Color)->Label:
 var l:=Label.new(); l.text=t; l.add_theme_font_size_override("font_size",size); l.add_theme_color_override("font_color",color); l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; return l
func _title(t:String,size:int,color:Color)->Label: return _label(t,size,color)
func _spacer(h:float)->Control: var c:=Control.new(); c.custom_minimum_size.y=h; return c
func _menu_button(parent:Control,text:String,action:Callable)->Button:
 var b:=Button.new(); b.text=text; b.custom_minimum_size.y=43; b.add_theme_font_size_override("font_size",14); b.add_theme_stylebox_override("normal",_box(Color("0d1b33"),Color("395b84"),1,7)); b.add_theme_stylebox_override("hover",_box(Color("162b4a"),Color("65d7ff"),2,7)); b.pressed.connect(action); parent.add_child(b); return b
func _circle_button(text:String,pos:Vector2,r:float,fill:Color,border:Color)->Button:
 var b:=Button.new(); b.text=text; b.position=pos-Vector2(r,r); b.size=Vector2(r*2,r*2); b.add_theme_stylebox_override("normal",_box(fill,border,2,int(r))); return b
func _action_button(parent:Control,text:String,pos:Vector2,size:float,key:String)->void:
 var b:=Button.new(); b.text=text; b.position=pos-Vector2(size/2,size/2); b.size=Vector2(size,size); b.add_theme_font_size_override("font_size",11); b.add_theme_stylebox_override("normal",_box(Color("0a1429e8"),Color("5caee0"),2,int(size/3))); parent.add_child(b)
 if key=="jump": b.pressed.connect(_jump)
 elif key=="attack": b.pressed.connect(func(): _attack("punch"))
 elif key=="kick": b.pressed.connect(func(): _attack("kick"))
 elif key=="block": b.button_down.connect(func(): block_hold=true); b.button_up.connect(func(): block_hold=false)
 elif key=="special": b.pressed.connect(_special)
 elif key=="ultimate": b.pressed.connect(_ultimate)

func _show_screen(which:String)->void:
 screen=which
 for n in ui.get_children():
  if n is Control and n.has_meta("visible_in_battle"): n.visible=which=="battle"
 # Known panels
 for n in ui.get_children():
  if n is PanelContainer:
   if n.name=="Menu": n.visible=which=="menu"
   elif n==roster_panel: n.visible=which=="roster"
   elif n==campaign_panel: n.visible=which=="campaign"
   elif n==settings_panel: n.visible=which=="settings"
 if which=="battle": _set_message("ROUND %02d  •  FIGHT!"%[stage+1])
 _refresh_roster(); queue_redraw()

func _refresh_roster()->void:
 if is_instance_valid(roster_info):
  var r=ROSTER[selected]; roster_info.text="%s  •  %s\nSIGNATURE: %s   |   ULTIMATE: %s\n\n%s"%[r.name,r.title,r.power,r.ultimate,_style_text(r.style)]
 if is_instance_valid(stage_info): stage_info.text="UNLOCKED STAGES: %d / 5     •     WINS: %d     •     LOSSES: %d"%[unlocked,wins,losses]

func _style_text(s:String)->String:
 match s:
  "rushdown": return "Fast pressure fighter. Dash cancels and close-range burst damage."
  "clone": return "Summoner fighter. Creates short-lived echo fighters with capped damage."
  "time": return "Control fighter. Slows and freezes with strict cooldowns."
  "rift": return "Mobility fighter. Teleports through safe, validated arena space."
  "mimic": return "Adaptive fighter. Stores one rival power and cannot recursively copy."
  "gravity": return "Control fighter. Pulls, launches and pins at mid range."
  "frost": return "Tempo fighter. Slow fields create punish windows."
  "solar": return "Power fighter. High-damage projectiles with visible startup."
  "phase": return "Evasion fighter. Brief intangibility followed by a counter window."
  _: return "Risk fighter. Reality effects trade stability for explosive damage."

func _start_battle(new_mode:String)->void:
 mode=new_mode; round_over=false; result_text=""; match_time=60.0; player_x=330; enemy_x=950; player_y=FLOOR_Y; enemy_y=FLOOR_Y; p_vy=0; e_vy=0; player_hp=100; enemy_hp=100; energy=100; enemy_energy=75; guard=false; invuln=0; freeze=0; slow=0; attack_timer=0; enemy_attack_timer=0; ability_cd=0; ultimate_cd=0; combo=0; combo_timer=0; clones.clear(); particles.clear(); texts.clear(); trails.clear(); _show_screen("battle")

func _jump()->void:
 if screen!="battle" or round_over: return
 if player_y>=FLOOR_Y-2:
  p_vy=-610
  _burst(Vector2(player_x,player_y-8),ROSTER[selected].accent,8,120)

func _attack(kind:String)->void:
 if screen!="battle" or round_over or attack_timer>0: return
 attack_kind=kind; attack_timer=0.30 if kind=="punch" else 0.42; attack_hit=false; _sfx("hit_light" if kind=="punch" else "hit_heavy")
 var dir:=_input_direction(); if dir.x!=0: last_dir=Vector2(sign(dir.x),0)
 _set_message(("LIGHT STRIKE" if kind=="punch" else "HEAVY KICK")+"  •  +"+str(combo+1)+" COMBO")

func _special()->void:
 if screen!="battle" or round_over: return
 if ability_cd>0: _set_message("SPECIAL COOLING DOWN  %.1fs"%ability_cd); return
 var dir:=_input_direction(); var cost:=18.0
 if energy<cost: _set_message("NOT ENOUGH ENERGY"); return
 energy-=cost; ability_cd=2.2; ability_flash=0.5; _sfx("special")
 var dname:=_dir_name(dir)
 var r=ROSTER[selected]
 _set_message(dname+"  •  "+r.power)
 _execute_directional_special(dir)

func _ultimate()->void:
 if screen!="battle" or round_over: return
 if ultimate_cd>0: _set_message("ULTIMATE READY IN %.1fs"%ultimate_cd); return
 if energy<35: _set_message("NEED 35 ENERGY FOR ULTIMATE"); return
 energy-=35; ultimate_cd=8.0; ability_flash=1.2; _sfx("ultimate")
 _set_message(ROSTER[selected].ultimate+"  •  REALITY BREAK")
 _burst(Vector2(enemy_x,enemy_y-95),ROSTER[selected].color,28,320)
 enemy_hp=maxf(0,enemy_hp-30)
 screen_shake=18; flash=0.18
 if selected==1:
  for i in 5: clones.append({"x":player_x+randf_range(-100,100),"life":3.5,"phase":randf_range(0,6)})
 elif selected==2: player_hp=minf(100,player_hp+22)
 elif selected==5: enemy_x=lerpf(enemy_x,player_x+sign(enemy_x-player_x)*65,0.65)
 elif selected==8: invuln=2.4
 elif selected==9: enemy_hp=maxf(0,enemy_hp-12); slow=2.0

func _execute_directional_special(dir:Vector2)->void:
 var style:String=ROSTER[selected].style
 var d:=_dir_name(dir)
 var sign_x:=1.0 if last_dir.x>=0 else -1.0
 if dir.x!=0: sign_x=sign(dir.x)
 match style:
  "rushdown":
   if d in ["UP","UP-RIGHT","UP-LEFT"]: p_vy=-500
   player_x=clampf(player_x+sign_x*180,ARENA_LEFT,ARENA_RIGHT); _damage_enemy(15,120); _slash_fx(player_x,enemy_x,ROSTER[selected].color)
  "clone":
   if clones.size()<6: clones.append({"x":player_x+dir.x*55,"life":5.0,"phase":randf()*6.0})
   if d=="DOWN" or d=="DOWN-LEFT" or d=="DOWN-RIGHT": _damage_enemy(8,100)
  "time":
   if d=="UP": freeze=1.15
   elif d in ["LEFT","RIGHT"]: player_x=clampf(player_x+dir.x*170,ARENA_LEFT,ARENA_RIGHT)
   elif d.begins_with("DOWN"): slow=2.0; _damage_enemy(10,110)
   else: _damage_enemy(14,130)
  "rift":
   var target:=clampf(player_x+sign_x*230,ARENA_LEFT+50,ARENA_RIGHT-50)
   if d=="UP": target=player_x
   player_x=target; _burst(Vector2(player_x,player_y-80),ROSTER[selected].accent,16,180); _damage_enemy(17,130)
  "mimic": _damage_enemy(14,135); _burst(Vector2(enemy_x,enemy_y-90),ROSTER[selected].accent,12,160)
  "gravity":
   enemy_x=lerpf(enemy_x,player_x+sign_x*75,0.65); _damage_enemy(13,145); _burst(Vector2(enemy_x,enemy_y-70),ROSTER[selected].accent,15,170)
  "frost":
   slow=2.3; _damage_enemy(11,120); _burst(Vector2(enemy_x,enemy_y-80),ROSTER[selected].accent,20,130)
  "solar":
   _damage_enemy(20,280); _projectile(Vector2(player_x,player_y-105),Vector2(sign_x,0),ROSTER[selected].accent)
  "phase":
   invuln=1.2; player_x=clampf(player_x+sign_x*140,ARENA_LEFT,ARENA_RIGHT); _damage_enemy(16,125)
  "chaos":
   _damage_enemy(12+randf()*10,150); screen_shake=10; flash=0.1; _burst(Vector2(enemy_x,enemy_y-100),ROSTER[selected].accent,18,220)

func _damage_enemy(amount:float,reach:float)->void:
 if abs(enemy_x-player_x)<=reach and abs(enemy_y-player_y)<135:
  enemy_hp=maxf(0,enemy_hp-amount); enemy_attack_timer=0.0; combo+=1; combo_timer=2.0; enemy_x=clampf(enemy_x+sign(enemy_x-player_x)*minf(42,amount*2),ARENA_LEFT,ARENA_RIGHT); _hit_fx(Vector2(enemy_x,enemy_y-100),ROSTER[selected].accent)

func _input_direction()->Vector2:
 var v:=joystick_pos-joystick_center if joystick_active else Vector2.ZERO
 if not joystick_active:
  var x:=float(Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT))-float(Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT))
  var y:=float(Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN))-float(Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP))
  v=Vector2(x,y)
 if v.length()<0.22: return last_dir
 v=v.normalized(); var sx:=1.0 if v.x>=0 else -1.0; var sy:=1.0 if v.y<0 else -1.0
 if abs(v.x)<0.38: return Vector2(0,sy)
 if abs(v.y)<0.38: return Vector2(sx,0)
 return Vector2(sx,-1 if v.y<0 else 1)

func _dir_name(v:Vector2)->String:
 if abs(v.x)<0.1 and abs(v.y)<0.1: return "NEUTRAL"
 if v.x>0 and v.y<0:return "UP-RIGHT"
 if v.x>0 and v.y>0:return "DOWN-RIGHT"
 if v.x<0 and v.y<0:return "UP-LEFT"
 if v.x<0 and v.y>0:return "DOWN-LEFT"
 if v.x>0:return "RIGHT"
 if v.x<0:return "LEFT"
 if v.y<0:return "UP"
 return "DOWN"

func _joystick_input(event:InputEvent)->void:
 if screen!="battle": return
 if event is InputEventScreenTouch:
  joystick_active=event.pressed
  if event.pressed: joystick_pos=event.position
  else: joystick_pos=joystick_center
 elif event is InputEventScreenDrag and joystick_active: joystick_pos=joystick_center+(event.position-joystick_center).limit_length(62)
 queue_redraw()

func _process(delta:float)->void:
 menu_time+=delta
 message_timer=maxf(0,message_timer-delta)
 if screen=="battle":
  if hitstop>0: hitstop=maxf(0,hitstop-delta); queue_redraw(); return
  _battle_process(delta)
 queue_redraw()

func _battle_process(delta:float)->void:
 var dt:=delta
 match_time=maxf(0,match_time-dt)
 energy=minf(100,energy+dt*6.5)
 ability_cd=maxf(0,ability_cd-dt); ultimate_cd=maxf(0,ultimate_cd-dt); freeze=maxf(0,freeze-dt); slow=maxf(0,slow-dt); invuln=maxf(0,invuln-dt); attack_timer=maxf(0,attack_timer-dt); enemy_attack_timer=maxf(0,enemy_attack_timer-dt); combo_timer=maxf(0,combo_timer-dt); screen_shake=maxf(0,screen_shake-dt); flash=maxf(0,flash-dt)
 if combo_timer<=0: combo=0
 var dir:=_input_direction()
 if not round_over:
  if abs(dir.x)>0.1: player_x=clampf(player_x+dir.x*280*dt,ARENA_LEFT,ARENA_RIGHT)
  if player_y<FLOOR_Y:
   p_vy+=1350*dt
   player_y+=p_vy*dt
   if player_y>=FLOOR_Y:
    player_y=FLOOR_Y
    p_vy=0
  if attack_timer>0 and not attack_hit and attack_timer<0.22: attack_hit=true; _damage_enemy(8 if attack_kind=="punch" else 13,135 if attack_kind=="punch" else 165)
  _enemy_ai(dt)
  for c in clones:
   c.life-=dt; c.phase+=dt*7; c.x=move_toward(c.x,enemy_x-sign(enemy_x-c.x)*60,190*dt)
   if abs(enemy_x-c.x)<100 and fmod(c.phase,2.0)<dt: enemy_hp=maxf(0,enemy_hp-2.5); _hit_fx(Vector2(enemy_x,enemy_y-85),ROSTER[selected].accent)
  clones=clones.filter(func(c):return c.life>0)
  _spawn_ambient_particles(dt)
  if enemy_hp<=0: _finish_round(true)
  elif player_hp<=0 or match_time<=0: _finish_round(false)
 hp_label.text="%s   %d HP"%[ROSTER[selected].name,int(maxf(0,player_hp))]
 enemy_label.text="RIVAL   %d HP"%int(maxf(0,enemy_hp))
 energy_label.text="ENERGY %03d   •   SPECIAL %s   •   ULT %s"%[int(energy),"READY" if ability_cd<=0 else ("%.1f"%ability_cd),"READY" if ultimate_cd<=0 else ("%.1f"%ultimate_cd)]
 timer_label.text="%02d"%int(ceil(match_time))
 combo_label.text=(str(combo)+" HIT COMBO") if combo>=2 else ""
 message_label.text=message if message_timer>0 else ""

func _enemy_ai(dt:float)->void:
 var factor:=1.0+stage*0.12
 if freeze>0: return
 var slow_factor:=0.45 if slow>0 else 1.0
 var dx:=player_x-enemy_x
 if abs(dx)>155: enemy_x=clampf(enemy_x+sign(dx)*135*dt*factor*slow_factor,ARENA_LEFT,ARENA_RIGHT)
 elif enemy_attack_timer<=0 and randf()<dt*(0.85+stage*0.12):
  enemy_attack_kind="heavy" if randf()<0.25 else "light"; enemy_attack_timer=0.36 if enemy_attack_kind=="light" else 0.52; enemy_attack_hit=false
 if enemy_attack_timer>0 and not enemy_attack_hit and enemy_attack_timer<0.18:
  enemy_attack_hit=true
  if invuln<=0 and not block_hold:
   var dmg:=8.0 if enemy_attack_kind=="light" else 13.0
   player_hp=maxf(0,player_hp-dmg); _hit_fx(Vector2(player_x,player_y-90),Color("ff6d74")); screen_shake=7

func _finish_round(won:bool)->void:
 if round_over:return
 round_over=true
 result_text="VICTORY" if won else "DEFEAT"
 if won:
  wins+=1
  _sfx("victory")
  unlocked=maxi(unlocked,min(5,stage+2))
 else:
  losses+=1
 _save()
 _set_message(result_text+"  •  "+("NEXT STAGE UNLOCKED" if won and stage+1<5 else "RETURN TO MENU"))

func _set_message(t:String)->void:
 message=t; message_timer=3.2

func _hit_fx(pos:Vector2,c:Color)->void:
 hitstop=0.045; screen_shake=maxf(screen_shake,7); flash=0.06; _burst(pos,c,10,180); texts.append({"pos":pos,"text":"HIT!","life":0.5,"c":c})
func _burst(pos:Vector2,c:Color,count:int,speed:float)->void:
 for i in count:
  var a:=randf()*TAU; particles.append({"p":pos,"v":Vector2(cos(a),sin(a))*randf_range(speed*0.35,speed),"life":randf_range(0.25,0.65),"c":c,"size":randf_range(2,6)})
func _slash_fx(a:float,b:float,c:Color)->void:
 for i in 5: trails.append({"a":Vector2(a,FLOOR_Y-95),"b":Vector2(b,FLOOR_Y-95)+Vector2(randf_range(-20,20),randf_range(-80,80)),"life":0.22,"c":c})
func _projectile(pos:Vector2,vel:Vector2,c:Color)->void:
 particles.append({"p":pos,"v":vel*280,"life":0.8,"c":c,"size":12,"projectile":true})
func _spawn_ambient_particles(dt:float)->void:
 if randf()<dt*16: particles.append({"p":Vector2(randf_range(20,1260),randf_range(130,520)),"v":Vector2(randf_range(-8,8),randf_range(-18,-5)),"life":randf_range(1,2),"c":Color(0.4,0.7,1,0.25),"size":randf_range(1,3)})
 for p in particles: p.life-=dt; p.p+=p.v*dt; p.v*=0.97
 particles=particles.filter(func(p):return p.life>0)
 for t in texts:t.life-=dt;t.pos.y-=22*dt
 texts=texts.filter(func(t):return t.life>0)
 for tr in trails:tr.life-=dt
 trails=trails.filter(func(tr):return tr.life>0)

func _unhandled_input(event:InputEvent)->void:
 if screen!="battle":return
 if event is InputEventKey and event.pressed and not event.echo and event.keycode==KEY_R and round_over:
  _start_battle(mode); return
 if event is InputEventKey and event.pressed and not event.echo and event.keycode==KEY_M and round_over:
  _show_screen("menu"); return
 if event is InputEventKey and event.pressed and not event.echo:
  match event.keycode:
   KEY_SPACE:_jump()
   KEY_J:_attack("punch")
   KEY_K:_attack("kick")
   KEY_L:_special()
   KEY_I:_ultimate()
   KEY_SHIFT:block_hold=true
 elif event is InputEventKey and not event.pressed and event.keycode==KEY_SHIFT:block_hold=false

func _draw()->void:
 var shake:=Vector2(randf_range(-screen_shake,screen_shake),randf_range(-screen_shake,screen_shake)) if screen_shake>0 else Vector2.ZERO
 draw_rect(Rect2(0,0,W,H),Color("03050d"))
 _draw_background()
 if screen=="battle":
  draw_set_transform(shake,0,Vector2.ONE)
  _draw_arena()
  _draw_fighter(player_x,player_y,ROSTER[selected].color,ROSTER[selected].accent,anim_time,attack_timer,attack_kind,block_hold,invuln>0,false,1.0)
  _draw_fighter(enemy_x,enemy_y,Color("2a3044"),Color("ff5362"),anim_time+1.7,enemy_attack_timer,enemy_attack_kind,false,freeze>0,true,1.0)
  for c in clones:_draw_fighter(c.x,FLOOR_Y,ROSTER[selected].accent,ROSTER[selected].color,anim_time+c.phase,0,"",false,0,false,0.72)
  for tr in trails:draw_line(tr.a,tr.b,tr.c,tr.life*9)
  for p in particles:
   if p.has("projectile"):draw_circle(p.p,p.size*maxf(0.2,p.life),p.c)
   else:draw_circle(p.p,p.size,p.c)
  for t in texts:draw_string(ThemeDB.fallback_font,t.pos,t.text,HORIZONTAL_ALIGNMENT_LEFT,-1,18,t.c)
  draw_set_transform(Vector2.ZERO,0,Vector2.ONE)
  if round_over:_draw_result()
 else:
  _draw_menu_hero()
 if flash>0:draw_rect(Rect2(0,0,W,H),Color(1,1,1,flash))

func _draw_background()->void:
 # Deep space + moon + ruined skyline
 draw_rect(Rect2(0,84,W,636),Color("050918"))
 for i in 16:
  var sx:=fposmod(i*97+menu_time*(8+i%3),W); var sy:=105+(i*43)%380
  draw_circle(Vector2(sx,sy),1.3,Color(0.65,0.82,1,0.45))
 draw_circle(Vector2(865,260),145,Color(0.16,0.28,0.48,0.20)); draw_circle(Vector2(865,260),112,Color("0d1930")); draw_arc(Vector2(865,260),116,-2.8,1.5,80,Color(0.5,0.75,1,0.5),4)
 # gothic towers
 for i in 13:
  var x:=i*105.0-20; var h:=100+(i*47)%190
  draw_rect(Rect2(x,FLOOR_Y-h,80,h),Color("090e1d")); draw_colored_polygon(PackedVector2Array([Vector2(x-10,FLOOR_Y-h),Vector2(x+40,FLOOR_Y-h-38),Vector2(x+90,FLOOR_Y-h)]),Color("0c1325"))
  draw_line(Vector2(x+40,FLOOR_Y-h-38),Vector2(x+40,FLOOR_Y-h-70),Color("223b61"),2)
  for wy in 3: draw_rect(Rect2(x+17,FLOOR_Y-h+28+wy*35,5,11),Color(0.25,0.55,0.85,0.25))
 # horizon glow
 draw_rect(Rect2(0,FLOOR_Y-5,W,5),Color("7e3c47"))

func _draw_arena()->void:
 draw_rect(Rect2(0,FLOOR_Y,W,H-FLOOR_Y),Color("070a13")); draw_rect(Rect2(0,FLOOR_Y,W,5),Color("ff713f"))
 for i in 12:draw_line(Vector2(i*115,FLOOR_Y),Vector2(i*115+60,H),Color(0.16,0.22,0.35,0.55),2)
 for i in 4:draw_line(Vector2(0,FLOOR_Y+25+i*35),Vector2(W,FLOOR_Y+25+i*35),Color(0.11,0.15,0.25,0.5),1)
 draw_arc(Vector2(W/2,FLOOR_Y+5),360,PI,TAU,70,Color(0.45,0.55,0.75,0.16),3)

func _draw_menu_hero()->void:
 var c=ROSTER[selected].color; var a=ROSTER[selected].accent
 draw_circle(Vector2(870,365),205,Color(c.r,c.g,c.b,0.08)); draw_arc(Vector2(870,365),180,0,TAU,100,Color(a.r,a.g,a.b,0.3),4); draw_arc(Vector2(870,365),135,menu_time*0.4,menu_time*0.4+5,80,Color(c.r,c.g,c.b,0.32),5)
 _draw_fighter(870,FLOOR_Y,c,a,menu_time,0,"",false,0,false,1.65)
 draw_string(ThemeDB.fallback_font,Vector2(590,625),"REALITY IS YOUR WEAPON",HORIZONTAL_ALIGNMENT_LEFT,-1,24,Color(0.75,0.83,1,0.85))
 draw_string(ThemeDB.fallback_font,Vector2(590,655),ROSTER[selected].name+"  •  "+ROSTER[selected].title,HORIZONTAL_ALIGNMENT_LEFT,-1,15,a)

func _draw_result()->void:
 draw_rect(Rect2(350,220,580,220),Color(2,5,14,0.92)); draw_rect(Rect2(350,220,580,220),Color(0.55,0.72,1,0.8),false,2)
 draw_string(ThemeDB.fallback_font,Vector2(350,285),result_text,HORIZONTAL_ALIGNMENT_CENTER,580,48,ROSTER[selected].accent)
 draw_string(ThemeDB.fallback_font,Vector2(350,325),"STAGE %02d  •  %s"%[stage+1,"CAMPAIGN" if mode=="campaign" else "TRAINING"],HORIZONTAL_ALIGNMENT_CENTER,580,16,Color("c8d7ee"))
 draw_string(ThemeDB.fallback_font,Vector2(350,365),"Press R to rematch   •   Press M to return",HORIZONTAL_ALIGNMENT_CENTER,580,14,Color("8ea8c9"))

func _draw_fighter(x:float,y:float,c:Color,a:Color,t:float,action_t:float,action:String,blocking:bool,phased:bool,rival:bool,s:float)->void:
 var bob:=sin(t*7.0)*3*s; var lean:=0.0; var atk:=action_t>0
 if atk:lean=0.18 if action=="punch" else -0.12
 var body:=c; if phased:body.a=0.42+0.2*sin(t*20)
 # shadow
 draw_ellipse(Vector2(x,y+2),Vector2(42*s,10*s),Color(0,0,0,0.42))
 # aura / silhouette rings
 draw_arc(Vector2(x,y-105*s),48*s,0,TAU,40,Color(c.r,c.g,c.b,0.18),3*s)
 if blocking:draw_arc(Vector2(x,y-108*s),68*s,-2.6,1.1,35,Color(a.r,a.g,a.b,0.85),6*s)
 if phased:draw_arc(Vector2(x,y-105*s),58*s,0,TAU,40,Color(0.6,0.8,1,0.65),3*s)
 # legs
 var step:=sin(t*10)*6*s if not atk else 0.0
 draw_line(Vector2(x-10*s,y-82*s+bob),Vector2(x-22*s+step,y-25*s),body,15*s,true)
 draw_line(Vector2(x+10*s,y-82*s+bob),Vector2(x+20*s-step,y-25*s),body,15*s,true)
 # torso
 draw_colored_polygon(PackedVector2Array([Vector2(x-22*s+lean*8*s,y-137*s+bob),Vector2(x+21*s+lean*8*s,y-137*s+bob),Vector2(x+14*s+lean*15*s,y-82*s+bob),Vector2(x-16*s+lean*15*s,y-82*s+bob)]),body)
 draw_line(Vector2(x-18*s,y-106*s),Vector2(x+18*s,y-96*s),a,4*s)
 # head + hair/mask
 draw_circle(Vector2(x+lean*18*s,y-159*s+bob),23*s,body)
 draw_colored_polygon(PackedVector2Array([Vector2(x-23*s+lean*18*s,y-166*s+bob),Vector2(x-5*s+lean*18*s,y-184*s+bob),Vector2(x+17*s+lean*18*s,y-180*s+bob),Vector2(x+25*s+lean*18*s,y-160*s+bob),Vector2(x+5*s+lean*18*s,y-169*s+bob)]),a)
 draw_circle(Vector2(x+8*s+lean*18*s,y-160*s+bob),3*s,Color("050913"))
 # arms / attacks
 if atk and action=="punch":
  draw_line(Vector2(x+12*s,y-116*s),Vector2(x+72*s,y-119*s),body,13*s,true); draw_circle(Vector2(x+78*s,y-119*s),9*s,a)
  draw_arc(Vector2(x+35*s,y-119*s),48*s,-0.5,0.8,22,Color(a.r,a.g,a.b,0.8),4*s)
 elif atk and action=="kick":
  draw_line(Vector2(x+9*s,y-87*s),Vector2(x+68*s,y-112*s),body,17*s,true); draw_circle(Vector2(x+75*s,y-114*s),10*s,a); draw_arc(Vector2(x+38*s,y-104*s),52*s,-1.0,0.4,24,Color(a.r,a.g,a.b,0.75),4*s)
 else:
  draw_line(Vector2(x-15*s,y-118*s),Vector2(x-34*s-step,y-91*s),body,11*s,true); draw_line(Vector2(x+15*s,y-118*s),Vector2(x+34*s+step,y-91*s),body,11*s,true)
 if rival: draw_arc(Vector2(x,y-158*s),28*s,3.4,5.8,24,Color(1,0.22,0.3,0.8),3*s)
 # character-specific insignia
 draw_circle(Vector2(x,y-111*s),6*s,Color(a.r,a.g,a.b,0.9)); draw_arc(Vector2(x,y-111*s),11*s,0,TAU,20,Color(a.r,a.g,a.b,0.55),2*s)

func draw_ellipse(center:Vector2,radii:Vector2,color:Color)->void:
 var pts:=PackedVector2Array(); for i in 40: var a:=TAU*i/40.0; pts.append(center+Vector2(cos(a)*radii.x,sin(a)*radii.y)); draw_colored_polygon(pts,color)

func _save()->void:
 var cfg:=ConfigFile.new(); cfg.set_value("progress","selected",selected); cfg.set_value("progress","unlocked",unlocked); cfg.set_value("progress","wins",wins); cfg.set_value("progress","losses",losses); cfg.save(save_path)
func _load_save()->void:
 var cfg:=ConfigFile.new(); if cfg.load(save_path)==OK: selected=int(cfg.get_value("progress","selected",0)); unlocked=int(cfg.get_value("progress","unlocked",1)); wins=int(cfg.get_value("progress","wins",0)); losses=int(cfg.get_value("progress","losses",0))

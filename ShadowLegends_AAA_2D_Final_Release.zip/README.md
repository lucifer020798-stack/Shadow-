# Shadow Legends: Beyond Reality — Android 2D Fighter

A self-contained Godot 4.3+ single-player 2D dark-fantasy arena fighter. **Online multiplayer is intentionally excluded from this release.**

## What is actually implemented
- 10 original playable champions with distinct power identities.
- Premium-inspired dark-fantasy UI layout matching the supplied reference direction without copying proprietary game assets.
- Procedurally animated 2D fighters with idle movement, attack poses, hit reactions, blocking, phasing and ability auras.
- 8-direction input parser: N/S/E/W + four diagonals, neutral, dead-zone and forgiving directional sampling.
- Direction + Special moves with distinct behavior for every direction and every champion (80 directional variants), plus default Special and Ultimate.
- Attack state machine with startup/active/recovery timing, input buffering through forgiving touch controls, hit detection, hit-stun, knockback, hit-stop and screen shake.
- Energy, cooldowns, invulnerability, freeze/slow effects, clone lifetime/cap and ability safety limits.
- CPU opponent with difficulty scaling by campaign stage; no impossible reaction logic.
- Campaign: five original arenas/stages with local progression and save data.
- Training / Versus mode, results, rematch, settings and progress reset.
- Touch controls designed for landscape phones, including a draggable virtual joystick and action cluster.
- Keyboard controls for desktop testing.
- Original SVG character card and arena art assets generated for this project.
- Android landscape project configuration and export preset.
- GitHub Actions workflow for Android export; requires a properly configured Godot/Android CI image or local runner.

## Controls
Touch: joystick + JUMP / ATK / KICK / BLOCK / SPECIAL / ULT.
Keyboard: A/D or arrows move, W/Up jump, S/Down contributes to direction, Space jump, J punch, K kick, L special, I ultimate, Shift block. After a round, R rematches and M returns to menu.

## Build Android
1. Install Godot 4.3+ and Android export templates.
2. Install Android SDK + JDK supported by your Godot version.
3. Import `project.godot`.
4. Project > Export > Android.
5. Set a unique package identifier and sign the release build with your own keystore.
6. Export a debug APK for device testing, then a signed release AAB/APK.

## GitHub
Push the folder contents to a repository root. The workflow in `.github/workflows/android.yml` is provided as a starting point; CI runner/export-template compatibility should be verified in your GitHub Actions environment.

## QA status
This environment does not contain the Godot executable or Android SDK, so the project was statically reviewed and packaged but **not truthfully reported as device-tested or APK-built** here. The included QA checklist distinguishes static review from runtime tests.

## Art / IP
All character and arena art in `assets/characters` and `assets/art` is original vector artwork generated for this project. The supplied concept image is retained only as a visual reference under `assets/ui_mockups`; no third-party game assets, characters, music or code are bundled.

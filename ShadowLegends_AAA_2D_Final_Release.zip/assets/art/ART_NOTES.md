# Original Art Pack

The SVG files in this directory were generated specifically for Shadow Legends: Beyond Reality. They are original vector artwork, not extracted from another game.

#!/usr/bin/env bash
set -euo pipefail
# Requires Godot 4.3+ with Android export templates and a configured Android SDK/JDK.
mkdir -p build
godot --headless --path . --export-debug "Android" build/ShadowLegends-debug.apk
printf '\nAPK created at build/ShadowLegends-debug.apk\n'
